



<?php include("inc/header.php") ?><br><br>

<div class="text-primary col bg-primary text-light pt-auto pb-auto h3" style="height: 45px; text-align: center;" >
Acceuil
</div>

<div class="container">
	<div class="row">
		
	<div class="card bg-light box ">	
<div class="card-body">
<a href="register.php" class="col-sm-4">
 <img src="img/Registration.png" alt="" width="100"
         height="100">
 <p>Enregistrement</p>
 </a>
</div>
</div>


<div class="card bg-light box">
<div class="card-body">
<a href="attendance.php" class="col-sm-4">
 <img src="img/signature.jpg" alt="" width="100"
         height="100">
 <p>Signature</p>
 </a>
</div>
</div>

<div class="card bg-light box">
<div class="card-body">
 <a href="teacher_login.php" class="col-sm-4">
 <img src="img/dashbord.png" alt="" width="100"
         height="100">
 <p>DashBoard</p>
 </a>
 </div>
 </div>

 <div class="card bg-light box">
<div class="card-body">
 <a href="student_login.php" class="col-sm-4">
 <img src="img/dashboard_student.jpg" alt="" width="100"
         height="100">
 <p>Espace Etudiant</p>
 </a>
 </div>
 </div>

</div>
</div>


<?php include("inc/footer.php") ?>

