

<?php include("inc/header.php") ?>


<article style="padding: 40px; ">
  
     <div class="container row d-flex flex-row justify-content-center p-10">

  <div class="admin-form shadow p-4">

	<div class=" card bg-light">
	<div class="card-body text center">
		<div class="card-text">
			<h2>
	<?php echo"Merci d'avoir signé votre presence en ce jour : " . date("d-m-Y") . " à " . date("H:i:s") ;?>
	<br><br>
	<a href="attendance.php" class="btn btn-primary pl-10">ok</a>
	</h2>
    </div>
    </div>
  
    </div>
    </div>
    </div>


</article>

<?php include("inc/footer.php") ?>



<!-- 

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
    alert("email ou mot de pass invalide");
    </script>
    


  -->